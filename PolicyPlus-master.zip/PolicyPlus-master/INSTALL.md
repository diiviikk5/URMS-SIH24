# Installing Policy Plus
Policy Plus requires the .NET Framework, version 4.5 or greater. If that doesn't already come with your Windows version, you can [download it from Microsoft](https://www.microsoft.com/en-us/download/details.aspx?id=30653).
You'll probably have to reboot your computer after installing the Framework.

Once that's done, you can run the Policy Plus executable without any other installation.