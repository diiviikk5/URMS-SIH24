# Attribution

All icons are from the [FamFamFam "Silk" set](http://www.famfamfam.com/lab/icons/silk/), available under Creative Commons Attribution 2.5.

Much information on the policy-related formats was gained from Microsoft documentation: [Group Policy File Formats](https://msdn.microsoft.com/en-us/library/aa374150(v=vs.85).aspx) and [Group Policy ADMX Syntax Reference Guide](https://technet.microsoft.com/en-us/library/cc753471(v=ws.10).aspx). [How to add, modify, or delete registry subkeys and values by using a .reg file](https://support.microsoft.com/en-us/help/310516/how-to-add--modify--or-delete-registry-subkeys-and-values-by-using-a) was a good start on understanding the exported Registry format.