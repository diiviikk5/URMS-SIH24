﻿' DO NOT MODIFY THIS FILE. It will be overwritten by version.bat.
Module VersionHolder
    Public Const Version As String = ""
End Module
